// Add Event Listener
document.getElementById("login-button").addEventListener("click", loginTest);

function loginTest() {
    
    // Input
    let username = document.getElementById("username-in").value;
    let password = document.getElementById("password-in").value;
    let message
    
    // Process
    if (username === "admin") {
        if (password === "1234") {
            message = "Login Successful";
        } else {
            message = "Invalid Password";
        }
    } else {
        message = "Invalid Username";
    }

    // Output
    alert(message);
}